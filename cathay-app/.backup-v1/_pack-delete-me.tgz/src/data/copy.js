// UI text, kept apart from components so it can be translated or served by an
// API later. Functions take the values that vary (for example the user's name).
export const COPY = {
  groups: {
    title: 'Travel groups',
    intro: 'Plan flights together, from any airport.',
    heading: 'Your groups',
    create: 'Create group',
    emptyTitle: 'No travel groups yet',
    emptyText: 'Create a group, share the link and plan flights together, from any airport.',
    chips: {
      creator: { label: 'Creator', tone: 'neutral' },
      member: { label: 'Member', tone: 'tint' },
      invitee: { label: 'Invited', tone: 'tint' },
      declined: { label: 'Declined', tone: 'neutral' },
    },
    status: {
      alone: '1 member · Invite your friends',
      members: (n) => `${n} members`,
      invited: (n, creator) => `${n} member${n === 1 ? '' : 's'} · Invitation from ${creator}`,
      declined: 'Invitation declined',
    },
  },
  createGroup: {
    title: 'Create group',
    description: 'Plan flights together, from any airport.',
    agreement:
      'Destination and dates are set when you create. Joining means accepting both.',
    submit: 'Create & Invite',
    submitting: 'Creating…',
    failed: 'We could not create the group. Please try again.',
    labels: { name: 'Group name', destination: 'Destination', dates: 'Travel dates' },
    errors: {
      nameRequired: 'Enter a group name.',
      destinationRequired: 'Enter a destination.',
      destinationUnsupported: 'Only Tokyo, Japan is available in this demo.',
      datesRequired: 'Choose your travel dates.',
      datesUnavailable: 'Only Nov 7–10, 2026 is available in this demo.',
    },
  },
  bonus: {
    heading: 'Look forward to +10% bonus miles',
    createText: 'Earn extra miles for traveling together.',
    inviteText: 'Get extra miles for travelling together. Bonus miles are not earned yet.',
  },
  members: {
    heading: 'Your travel group',
    pickFlight: 'Pick flight →',
    equalRights: 'All members have equal rights',
    inviteHeading: 'Group invite link',
    shareInvite: 'Share invite',
    copyLabel: 'Copy invite link',
    copied: 'Link Copied',
    copyFailed: 'Could not copy automatically. The link is selected, so you can copy it yourself.',
    copiedAnnouncement: 'Invite link copied to clipboard',
    guidanceTitle: 'Friends can fly from different airports',
    guidanceText: 'Joining automatically accepts destination and dates.',
    notFoundTitle: 'Group not found',
    notFoundText: 'This group does not exist, or you do not have access to it.',
  },
  invite: {
    title: (name) => `Hello ${name}, You’re invited!`,
    rightsTitle: 'All members have equal rights',
    rightsText:
      'Joining accepts Tokyo and Nov 7–10. Choose your departure airport and coordinate flights with friends.',
    join: 'Join',
    joining: 'Joining…',
    decline: 'Decline',
    actionFailed: 'That did not work. Please try again.',
    sheet: {
      title: 'Decline invitation?',
      text: 'You won’t join this group. You can still change your mind later.',
      keep: 'Keep invitation',
      confirm: 'Decline invitation',
      confirming: 'Declining…',
    },
    declined: {
      pageTitle: 'Invitation declined',
      title: 'Invitation declined',
      text: (group) => `You didn’t join ${group}. You can still join later.`,
      joinInstead: 'Join instead',
      back: 'Back to Travel groups',
    },
    unavailable: {
      pageTitle: 'Invitation',
      title: 'This invitation isn’t available',
      reasons: {
        invite_not_found:
          'The link may be incorrect. Ask your friend to send a new link.',
      },
      toGroups: 'Go to Travel groups',
      create: 'Create your own group',
    },
  },
  comingSoon: {
    heading: 'Coming up in the next review',
    text: 'This screen is part of a later flow in the demo.',
    otherTab: 'This tab is not part of the demo.',
  },
  notFound: {
    title: 'Page not found',
    text: 'We could not find that page.',
    action: 'Start again',
  },
};
