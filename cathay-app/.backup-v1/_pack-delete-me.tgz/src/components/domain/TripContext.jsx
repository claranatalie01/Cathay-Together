import './TripContext.css';

// Photo, destination, dates and a one-line status for the current group.
export default function TripContext({ photo, title, dates, status }) {
  return (
    <div className="trip-context">
      <div className="trip-context__photo">
        <img src={photo.src} alt={photo.alt} />
      </div>
      <div className="trip-context__info">
        <p className="trip-context__title">{title}</p>
        <p className="trip-context__dates">{dates}</p>
        <p className="trip-context__status">{status}</p>
      </div>
    </div>
  );
}
