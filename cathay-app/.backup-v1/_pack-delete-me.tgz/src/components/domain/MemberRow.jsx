import { MEMBER_STATUS } from '../../data/memberStatus';
import Chip from '../ui/Chip';
import './MemberRow.css';

// One member of a travel group: avatar, name, home airport and flight status.
export default function MemberRow({ member }) {
  const status = MEMBER_STATUS[member.status];
  const name = `${member.name}${member.isViewer ? ' (you)' : ''}${member.isCreator ? ' · Creator' : ''}`;
  return (
    <li className="member">
      <span className="member__avatar" aria-hidden="true">
        {member.initial}
      </span>
      <div className="member__details">
        <p className="member__name">{name}</p>
        <p className="member__origin">
          {member.airport.code} · {member.airport.city}
        </p>
      </div>
      <Chip tone={status.tone}>{status.label}</Chip>
    </li>
  );
}
