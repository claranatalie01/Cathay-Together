import { Link, useParams } from 'react-router-dom';
import { NAV_TABS, NAV_VARIANTS, navPath } from '../../data/nav';
import './BottomNav.css';

function TabIcon({ tab, variant }) {
  const rotated = tab === 'book' && variant.bookRotated;
  let extra = '';
  if (rotated) extra = ' bottom-nav__icon--rotated';
  if (tab === 'groups' && variant.groupsAlt) extra = ' bottom-nav__icon--groups-alt';
  if (tab === 'home' && variant.homeAlt) extra = ' bottom-nav__icon--home-alt';
  if (tab === 'home' && variant.homeAlt2) extra = ' bottom-nav__icon--home-alt2';
  const img = (
    <span className="bottom-nav__icon-elements">
      <img src={`/assets/${variant.icons[tab]}`} alt="" />
    </span>
  );
  return (
    <span className={`bottom-nav__icon bottom-nav__icon--${tab}${extra}`}>
      {rotated ? <span className="bottom-nav__icon-turn">{img}</span> : img}
    </span>
  );
}

export default function BottomNav({ variant = 'groups' }) {
  const { groupId } = useParams();
  const config = NAV_VARIANTS[variant];

  return (
    <nav className="bottom-nav" aria-label="Primary">
      <div className="bottom-nav__inner">
        {NAV_TABS.map((tab) => {
          const isActive = config.active === tab.key;
          return (
            <Link
              key={tab.key}
              className="bottom-nav__tab"
              to={navPath(tab.key, groupId)}
              aria-current={isActive ? 'page' : undefined}
            >
              <TabIcon tab={tab.key} variant={config} />
              <span
                className={`bottom-nav__label bottom-nav__label--${tab.key}${isActive ? ' bottom-nav__label--active' : ''}`}
              >
                {tab.key === 'groups' ? (
                  <>
                    Travel
                    <br />
                    Groups
                  </>
                ) : (
                  tab.label
                )}
              </span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
