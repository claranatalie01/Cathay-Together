import { Link } from 'react-router-dom';
import './Button.css';

// Full-width action. Renders a router link when `to` is given, otherwise a <button>.
export default function Button({ to, variant = 'primary', type = 'button', className = '', children, ...rest }) {
  const classes = `button${variant === 'secondary' ? ' button--secondary' : ''} ${className}`.trim();
  if (to) {
    return (
      <Link className={classes} to={to} {...rest}>
        {children}
      </Link>
    );
  }
  return (
    <button className={classes} type={type} {...rest}>
      {children}
    </button>
  );
}
