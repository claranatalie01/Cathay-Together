// The mock "database": users, groups and the signed-in session, persisted in
// localStorage. Only src/api/mock and src/demo import this file.
const KEY = 'cathay-mock-db-v2';

export const USERS = {
  clara: { id: 'clara', name: 'Clara', initial: 'C', airport: { code: 'SHA', city: 'Shanghai' } },
  gaudi: { id: 'gaudi', name: 'Gaudi', initial: 'G', airport: { code: 'HKG', city: 'Hong Kong' } },
  kabe: { id: 'kabe', name: 'Kabe', initial: 'K', airport: { code: 'SIN', city: 'Singapore' } },
};

// Windows the server accepts when creating a group.
export const DATE_WINDOWS = {
  'nov-7-10': { label: 'Nov 7–10, 2026', available: true },
  'nov-14-17': { label: 'Nov 14–17, 2026', available: false },
  'nov-21-24': { label: 'Nov 21–24, 2026', available: false },
};

const INVITE_BASE_URL = 'https://flights.cathaypacific.com/share/';
export const inviteUrlFor = (code) => `${INVITE_BASE_URL}${code}`;

function seed() {
  return {
    session: { currentUserId: 'gaudi' },
    groups: [
      {
        id: 'tokyo-together',
        name: 'Tokyo together',
        destination: 'Tokyo, Japan',
        datesLabel: 'Nov 7–10, 2026',
        code: 'VFX37K',
        creatorId: 'gaudi',
        inviteCopied: false,
        createdAt: 1,
        members: [
          { userId: 'gaudi', status: 'booked' },
          { userId: 'kabe', status: 'picked' },
        ],
        invitations: [{ userId: 'clara', status: 'pending' }],
      },
    ],
  };
}

let db = null;

function load() {
  try {
    const saved = JSON.parse(localStorage.getItem(KEY));
    if (saved && Array.isArray(saved.groups) && saved.session) return saved;
  } catch {
    // Missing or corrupt: start from the seed.
  }
  return seed();
}

export function getDb() {
  if (!db) db = load();
  return db;
}

export function saveDb() {
  try {
    localStorage.setItem(KEY, JSON.stringify(getDb()));
  } catch {
    // Storage unavailable: data lives in memory for this page load.
  }
}

export function resetDb() {
  db = seed();
  saveDb();
}
