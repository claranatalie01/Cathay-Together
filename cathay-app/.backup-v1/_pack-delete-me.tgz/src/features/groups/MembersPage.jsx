import { useEffect, useRef, useState } from 'react';
import { Link, Navigate, useNavigate, useParams } from 'react-router-dom';
import { ApiError, getGroup, markInviteCopied } from '../../api';
import Screen from '../../components/layout/Screen';
import StatusBar from '../../components/layout/StatusBar';
import PageHeader from '../../components/layout/PageHeader';
import BottomNav from '../../components/layout/BottomNav';
import MemberRow from '../../components/domain/MemberRow';
import SectionHeading from '../../components/domain/SectionHeading';
import TripContext from '../../components/domain/TripContext';
import Button from '../../components/ui/Button';
import ErrorState from '../../components/ui/ErrorState';
import LoadingState from '../../components/ui/LoadingState';
import StateMessage from '../../components/ui/StateMessage';
import { useToast } from '../../components/ui/Toast';
import { DemoControls } from '../../demo';
import { COPY } from '../../data/copy';
import { TRIP_PHOTO } from '../../data/trip';
import { copyText } from '../../hooks/copyText';
import { useAsync } from '../../hooks/useAsync';
import { useDocumentTitle } from '../../hooks/useDocumentTitle';
import { memberSummary, orderedMembers } from './groupSelectors';
import './MembersPage.css';

export default function MembersPage() {
  const { groupId } = useParams();
  const navigate = useNavigate();
  const toast = useToast();
  const { status, data: group, error, reload } = useAsync(() => getGroup(groupId), [groupId]);
  const [justCopied, setJustCopied] = useState(false);
  const resetTimer = useRef();
  const urlRef = useRef(null);
  const copy = COPY.members;

  useDocumentTitle(group ? group.name : status === 'loading' ? undefined : 'Group');
  useEffect(() => () => clearTimeout(resetTimer.current), []);

  const frame = (title, body) => (
    <Screen>
      <StatusBar />
      <PageHeader title={title} onBack={() => navigate('/groups')} />
      {body}
      <BottomNav variant="groups" />
    </Screen>
  );

  if (status === 'loading') return frame('Group', <LoadingState />);
  if (status === 'error') {
    if (error instanceof ApiError && error.status === 404) {
      return frame(
        copy.notFoundTitle,
        <StateMessage mark="!" tone="sand" title={copy.notFoundTitle} text={copy.notFoundText}>
          <Button to="/groups">{COPY.invite.declined.back}</Button>
        </StateMessage>,
      );
    }
    return frame('Group', <ErrorState error={error} onRetry={reload} />);
  }
  // Someone who has not joined yet is sent to the invitation first.
  if (!group.viewerId) return <Navigate to={`/invite/${group.code}`} replace />;

  const members = orderedMembers(group);
  const showRights = members.length > 1 || group.inviteCopied;
  const url = group.inviteUrl;

  const showCopied = () => {
    setJustCopied(true);
    clearTimeout(resetTimer.current);
    resetTimer.current = setTimeout(() => setJustCopied(false), 4000);
    markInviteCopied(group.id).catch(() => {});
  };

  const onCopy = async () => {
    if (await copyText(url)) {
      showCopied();
      return;
    }
    // Clipboard blocked by the browser: select the link so it can be copied by hand.
    if (urlRef.current) {
      const range = document.createRange();
      range.selectNodeContents(urlRef.current);
      window.getSelection()?.removeAllRanges();
      window.getSelection()?.addRange(range);
    }
    toast(copy.copyFailed);
  };

  const onShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({ title: group.name, text: `Join ${group.name} on Cathay Together`, url });
        return;
      } catch (shareError) {
        if (shareError?.name === 'AbortError') return;
      }
    }
    await onCopy();
  };

  return frame(
    group.name,
    <main className="members">
      <TripContext
        photo={TRIP_PHOTO}
        title={group.destination}
        dates={group.datesLabel}
        status={memberSummary(members)}
      />
      <section className="group-members" aria-labelledby="members-heading">
        <SectionHeading
          id="members-heading"
          title={copy.heading}
          action={
            <Link className="section-heading__action" to={`/groups/${group.id}/flights/search`}>
              {copy.pickFlight}
            </Link>
          }
        />
        {showRights && <p className="group-members__note">{copy.equalRights}</p>}
        <ul className="member-list">
          {members.map((member) => (
            <MemberRow key={member.userId} member={member} />
          ))}
        </ul>
      </section>
      <section className="invite-share" aria-labelledby="invite-heading">
        <SectionHeading
          id="invite-heading"
          title={copy.inviteHeading}
          small
          startAligned
          action={
            <button className="section-heading__action" type="button" onClick={onShare}>
              {copy.shareInvite}
            </button>
          }
        />
        <div className="invite-link">
          <p ref={urlRef} className={`invite-link__url${justCopied ? ' invite-link__url--copied' : ''}`}>
            {url}
            {justCopied && (
              <>
                {'        '}
                <span className="invite-link__copied">{copy.copied}</span>
              </>
            )}
          </p>
          <button
            className={`invite-link__copy${justCopied ? ' invite-link__copy--alt' : ''}`}
            type="button"
            onClick={onCopy}
            aria-label={copy.copyLabel}
          >
            <span className="invite-link__copy-elements">
              <img src={justCopied ? '/assets/c9816.svg' : '/assets/76582.svg'} alt="" />
            </span>
          </button>
        </div>
        <span className="sr-only" role="status">
          {justCopied ? copy.copiedAnnouncement : ''}
        </span>
      </section>
      <aside className="guidance">
        <h3 className="guidance__title">{copy.guidanceTitle}</h3>
        <p className="guidance__text">{copy.guidanceText}</p>
      </aside>
      <DemoControls context="members" group={group} />
    </main>,
  );
}
