import { useState } from 'react';
import BonusTeaser from '../components/domain/BonusTeaser';
import GroupCard from '../components/domain/GroupCard';
import MemberRow from '../components/domain/MemberRow';
import SectionHeading from '../components/domain/SectionHeading';
import TripContext from '../components/domain/TripContext';
import BottomNav from '../components/layout/BottomNav';
import PageHeader from '../components/layout/PageHeader';
import Screen from '../components/layout/Screen';
import StatusBar from '../components/layout/StatusBar';
import Button from '../components/ui/Button';
import Chip from '../components/ui/Chip';
import Field from '../components/ui/Field';
import LoadingState from '../components/ui/LoadingState';
import Sheet from '../components/ui/Sheet';
import StateMessage from '../components/ui/StateMessage';
import { useToast } from '../components/ui/Toast';
import { TRIP_PHOTO } from '../data/trip';
import Badge from './Badge';
import { CHECKLIST, PLANNED } from './catalog';

function Block({ id, title, figma, proposal, rule, children }) {
  return (
    <section className="ds-block" aria-labelledby={id}>
      <div className="ds-block__head">
        <h3 className="ds-block__title" id={id}>
          {title}
        </h3>
        {figma && <Badge kind="source" />}
        {proposal && <Badge kind="proposal" />}
      </div>
      {figma && <p className="ds-block__text">Figma: {figma}</p>}
      {proposal && <p className="ds-block__text">Proposal: {proposal}</p>}
      {rule && <p className="ds-block__rule">Rule: {rule}</p>}
      {children}
    </section>
  );
}

const Spec = ({ label, children }) => (
  <div className="ds-spec">
    <span className="ds-spec__label">{label}</span>
    {children}
  </div>
);

const SAMPLE_MEMBERS = [
  { userId: 'a', name: 'Gaudi', initial: 'G', airport: { code: 'SIN', city: 'Singapore' }, status: 'booked', isCreator: true },
  { userId: 'b', name: 'Clara', initial: 'C', airport: { code: 'HKG', city: 'Hong Kong' }, status: 'picked', isViewer: true },
  { userId: 'c', name: 'Mei', initial: 'M', airport: { code: 'TPE', city: 'Taipei' }, status: 'browsing' },
];

const noop = () => {};

function ButtonBlock() {
  return (
    <Block
      id="ds-button"
      title="Button"
      figma="primary and secondary, 52px full width."
      proposal="hover, pressed, focus, disabled and loading (Figma has none)."
      rule="One primary button per screen. Loading keeps the label, sets disabled and aria-busy. Disabled is only for actions that cannot run yet."
    >
      <div className="ds-specs">
        <Spec label="Primary"><Button>Create group</Button></Spec>
        <Spec label="Secondary"><Button variant="secondary">Back to groups</Button></Spec>
        <Spec label="Hover"><Button className="is-hover">Create group</Button></Spec>
        <Spec label="Pressed"><Button className="is-pressed">Create group</Button></Spec>
        <Spec label="Focus"><Button className="is-focus">Create group</Button></Spec>
        <Spec label="Disabled"><Button disabled>Create group</Button></Spec>
        <Spec label="Loading"><Button disabled aria-busy="true">Creating…</Button></Spec>
        <Spec label="Secondary hover"><Button variant="secondary" className="is-hover">Back to groups</Button></Spec>
      </div>
    </Block>
  );
}

function ChipBlock() {
  return (
    <Block id="ds-chip" title="Chip" figma="neutral, tint, sand and primary tones." rule="Status only; chips are not interactive. Never rely on colour alone: the label carries the meaning.">
      <div className="ds-specs ds-specs--row">
        <Spec label="Neutral"><Chip>Browsing</Chip></Spec>
        <Spec label="Primary"><Chip tone="primary">Picked</Chip></Spec>
        <Spec label="Sand"><Chip tone="sand">Booked</Chip></Spec>
        <Spec label="Tint"><Chip tone="tint">Invited</Chip></Spec>
      </div>
    </Block>
  );
}

function FieldBlock() {
  return (
    <Block
      id="ds-field"
      title="Field"
      figma="default text field and select with icon."
      proposal="hover, focus, error and disabled. Error and focus keep the Figma border colour logic; a stronger border is a separate proposal."
      rule="Every field has a visible label. Errors appear under the field, use role=alert and are linked with aria-describedby."
    >
      <div className="ds-specs">
        <Spec label="Default">
          <Field id="ds-f1" label="Group name"><input className="field__text" id="ds-f1" defaultValue="Tokyo together" /></Field>
        </Spec>
        <Spec label="Hover">
          <Field id="ds-f2" label="Group name" valueClassName="is-hover"><input className="field__text" id="ds-f2" defaultValue="Tokyo together" /></Field>
        </Spec>
        <Spec label="Focus">
          <Field id="ds-f3" label="Group name" valueClassName="is-focus"><input className="field__text" id="ds-f3" defaultValue="Tokyo together" /></Field>
        </Spec>
        <Spec label="Error">
          <Field id="ds-f4" label="Group name" error="Enter a group name."><input className="field__text" id="ds-f4" aria-invalid="true" aria-describedby="ds-f4-error" /></Field>
        </Spec>
        <Spec label="Disabled">
          <Field id="ds-f5" label="Group name" disabled><input className="field__text" id="ds-f5" defaultValue="Tokyo together" disabled /></Field>
        </Spec>
        <Spec label="Select">
          <Field id="ds-f6" label="Dates" disclosure="▾">
            <select className="field__text" id="ds-f6" defaultValue="a"><option value="a">Nov 7–10, 2026</option></select>
          </Field>
        </Spec>
      </div>
    </Block>
  );
}

function CardBlock() {
  return (
    <Block id="ds-cards" title="Cards and rows" figma="trip context, group card, member row, bonus teaser, section heading." proposal="hover and pressed on the group card." rule="A whole card is one link; do not nest a second link or button inside it.">
      <div className="ds-specs">
        <Spec label="Group card"><GroupCard to="/groups" photo={TRIP_PHOTO} name="Tokyo together" meta="Nov 7–10, 2026" status="3 members" chip={{ tone: 'tint', label: 'Invited' }} /></Spec>
        <Spec label="Group card, hover"><GroupCard className="is-hover" to="/groups" photo={TRIP_PHOTO} name="Tokyo together" meta="Nov 7–10, 2026" status="3 members" chip={{ tone: 'tint', label: 'Invited' }} /></Spec>
        <Spec label="Group card, pressed"><GroupCard className="is-pressed" to="/groups" photo={TRIP_PHOTO} name="Tokyo together" meta="Nov 7–10, 2026" status="3 members" chip={{ tone: 'tint', label: 'Invited' }} /></Spec>
        <Spec label="Trip context"><TripContext photo={TRIP_PHOTO} title="Tokyo, Japan" dates="Nov 7–10, 2026" status="Group set up" /></Spec>
        <Spec label="Member rows"><ul className="ds-list">{SAMPLE_MEMBERS.map((member) => <MemberRow key={member.userId} member={member} />)}</ul></Spec>
        <Spec label="Section heading"><SectionHeading title="Members" action={<button className="section-heading__action" type="button">Share invite</button>} /></Spec>
        <Spec label="Bonus teaser"><BonusTeaser heading="Book together, earn more" text="Sample copy for the bonus teaser." /></Spec>
      </div>
    </Block>
  );
}

function LayoutBlock() {
  return (
    <Block id="ds-layout" title="Status bar, page header, bottom nav" figma="all three; bottom nav shows Travel Groups or Book active." proposal="hover and pressed on the back button and tabs (real pseudo-classes only; try them below)." rule="Every screen starts with status bar and page header. The page title is the h1 and takes focus after navigation.">
      <div className="ds-frames">
        <Screen className="ds-frame ds-frame--short"><StatusBar /><PageHeader title="Page title" titleAs="h4" titleId="ds-page-title" onBack={noop} /></Screen>
        <Screen className="ds-frame ds-frame--short"><BottomNav variant="groups" /></Screen>
      </div>
    </Block>
  );
}

function SheetBlock() {
  const [open, setOpen] = useState(false);
  const toast = useToast();
  return (
    <Block id="ds-overlay" title="Sheet, state message, skeleton, toast" figma="sheet with handle; confirmation and building states." proposal="empty, error and unavailable messages, skeleton and toast." rule="Messages say what happened and what to do next. Sheets trap focus, close on Escape and return focus to the opener.">
      <div className="ds-frames">
        <Screen className="ds-frame">
          <div className="ds-frame__body">
            <Button variant="secondary" onClick={() => setOpen(true)}>Open sheet</Button>
          </div>
          <Sheet open={open} onClose={() => setOpen(false)} title="Sheet title" titleId="ds-sheet-title">
            <p className="sheet__text">Sheet body text explains the choice.</p>
            <Button onClick={() => setOpen(false)} data-autofocus>Confirm</Button>
          </Sheet>
        </Screen>
        <Screen className="ds-frame"><StateMessage as="div" mark="!" tone="sand" title="Something went wrong" text="We could not reach the service. Check your connection and try again."><Button>Retry</Button></StateMessage></Screen>
        <Screen className="ds-frame"><StateMessage as="div" mark="✓" title="Invite sent" text="Your friends can join with the link." /></Screen>
        <Screen className="ds-frame"><LoadingState as="div" variant="list" /></Screen>
      </div>
      <div className="ds-specs">
        <Spec label="Toast"><Button variant="secondary" onClick={() => toast('Link copied')}>Show toast</Button></Spec>
      </div>
    </Block>
  );
}

export function ComponentSections() {
  return (
    <section className="ds-section" aria-labelledby="ds-components">
      <h2 className="ds-section__title" id="ds-components">Components</h2>
      <p className="ds-section__text">
        These are the real components the screens use. States named Hover, Pressed and Focus are shown with
        mirror classes (<code>is-hover</code>, <code>is-pressed</code>, <code>is-focus</code>); the real
        pseudo-classes behave the same, so hover and Tab to the plain examples to see them.
      </p>
      <ButtonBlock />
      <ChipBlock />
      <FieldBlock />
      <CardBlock />
      <LayoutBlock />
      <SheetBlock />
    </section>
  );
}

export function PlannedSection() {
  return (
    <section className="ds-section" aria-labelledby="ds-planned">
      <h2 className="ds-section__title" id="ds-planned">Defined in Figma, not built yet</h2>
      <p className="ds-section__text">Built from this guide when the screen that needs them arrives.</p>
      <table className="ds-table">
        <thead><tr><th scope="col">Component</th><th scope="col">Variants</th><th scope="col">Note</th></tr></thead>
        <tbody>{PLANNED.map(([name, variants, note]) => <tr key={name}><td>{name}</td><td>{variants}</td><td>{note}</td></tr>)}</tbody>
      </table>
    </section>
  );
}

export function ChecklistSection() {
  return (
    <section className="ds-section" aria-labelledby="ds-checklist">
      <h2 className="ds-section__title" id="ds-checklist">Checklist for every screen</h2>
      <ol className="ds-checklist">{CHECKLIST.map((item) => <li key={item}>{item}</li>)}</ol>
    </section>
  );
}
