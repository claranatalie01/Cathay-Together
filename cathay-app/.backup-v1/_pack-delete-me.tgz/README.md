# Cathay Together demo (React + Vite)

Interactive demo of the Cathay Together group-booking prototype.
The original static prototype is untouched in `../frontend`.

## Run it

```bash
npm install        # first time only
npm run dev        # http://localhost:5173
npm run build      # production build into dist/
npm run preview    # serve the production build
```

Needs Node.js 20+ (`brew install node`).

## Review shortcuts

- `/groups` – Travel Groups list (the nav tab)
- `/groups/new` – start of the group set-up flow (also what `/` opens)
- `/invite/VFX37K` – the invitation link for the sample group
- `/design-system` – living style guide (tokens and real components; no demo panel)
- `/reset` – clear saved demo data (demo only)

## Structure

- `src/styles` – design tokens (`tokens.css`, the only place raw values may be written), base and app-shell CSS
- `src/design-system` – the `/design-system` style guide; rules in `docs/design-system.md`; `npm run check:tokens` enforces tokens-only CSS
- `src/components` – `layout/`, `ui/` (Button, Chip, Field, Sheet, Toast, StateMessage, LoadingState, ErrorState), `domain/`
- `src/features` – pages, one folder per flow
- `src/api` – the only place pages get data from (see below)
- `src/data` – UI text and static options (not server data)
- `src/demo` – demo-only controls (see below)
- `docs/api-contract.md` – endpoints, request and response JSON for the backend

## Data layer

Pages import only from `src/api` (`getGroups`, `getGroup`, `getGroupByCode`, `createGroup`,
`joinGroup`, `declineInvite`, `markInviteCopied`, `getCurrentUser`). Each function is async and
returns the JSON in `docs/api-contract.md`. They call `request()` in `src/api/http.js`, which is
answered by a mock backend in `src/api/mock/` that saves to `localStorage`.

**To connect a real backend:** replace the body of `request()` in `src/api/http.js` with a `fetch`
to your API (same paths and JSON, throw `ApiError` on non-2xx). Then delete `src/api/mock/`.

## Demo controls (and how to remove them)

`src/demo` holds the "Demo only" panel (switch the viewing person, simulate invitations, expire
force an API error, reset) and the `/reset` route. The real invite link `/invite/CODE`
works without it. To remove it:

1. Delete the `src/demo` folder.
2. Remove the `DemoControls` import and `<DemoControls … />` line in `MembersPage.jsx`,
   `InvitePage.jsx` and `GroupsPage.jsx`.
3. Remove the `ResetPage` import and the `reset` route in `App.jsx`.
