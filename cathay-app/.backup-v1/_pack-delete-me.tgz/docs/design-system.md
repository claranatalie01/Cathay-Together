# Cathay Together design system (v2.0, real-app first)

Every screen follows this system. The live style guide is at **`/design-system`**
(run `npm run dev`, open <http://localhost:5173/design-system>). It reads `src/styles/tokens.css`.

> **Status of this document.** v2.0 changes the *documented* values. `src/styles/tokens.css`,
> component CSS and the style guide **have not been updated yet** and still hold the v1.0 values.
> Until they are, the code and this document disagree. Section 10 lists every token whose value changes.
> The previous version is kept as `docs/design-system.v1.0.backup.md`.

## 0. Source priority (this is the rule)

1. **Real Cathay Pacific app screenshots win.** 14 screenshots of the real Android app (`docs/screenshot-audit.md` has the measurements and screenshot key S1 to S14).
2. **Where the screenshots are silent, the Figma / v1.0 value is kept**, unchanged.
3. **Where neither exists, the item is a PROPOSAL** and needs approval.

If the screenshots and the old document disagree, this document uses the screenshot value. Nothing is renamed or merged unless this document says so.

**Status labels** (used in every table and in token comments)

| Label | Meaning |
|---|---|
| **Real** | Read from the real app. Flat fills and clear edges (±2 per colour channel, ±1 px). |
| **Real (est.)** | From the real app but judged from thin text, thin strokes or a curve. The ± is stated or implied (colour ±8, radius ±1.5 dp, font size ±1.5 sp). |
| **Figma (kept)** | Not visible in the screenshots, so the v1.0 value is kept. Not verified against the real app. |
| **PROPOSAL** | Not in the real app or Figma. Needs approval. |
| **Flagged** | A value with a contrast or near-duplicate issue. Kept as observed. |

**Units.** The real app is about 411 dp wide (screenshots 1.796 px per dp). The demo frame is 440 px. Gutter (24) and button height (52) match 1:1, so real dp values are used as CSS px. The dp conversion is inferred, so every size is "Real (est.)" at about ±0.6 dp.

## 1. What the real app shows (summary)

- Grey canvas with **white cards** (the inverse of v1.0).
- Primary button is **dark green `#2c4035`**, white label, 52 or 56 dp tall, radius 8.
- Text is **neutral grey** (primary about `#262626`, secondary about `#6b6b6b`). Dividers are neutral `#e8e8e8`.
- The teal splits into a **mid-teal** (`#336c6a`: codes, links, active tab, selection) and a **deep teal** (`#035256`: fare tier names, table heads).
- Bottom sheets have a **16** top radius and a neutral black scrim.
- Gutter is **24** on Book, Results, Fare and Fill-in, and **16** on Home and Express checkout.
- Bottom nav is Home, Book, My trips, Profile, Travel tools. There is no "Travel Groups".

Figma defined only three shared styles (v1.0 section 1): colour style "Dark" `#141B34` (13 icon files), effect style "XXS Shadow", and colour variable "#D9D9D9" resolving to `#CFCFCF`. Figma has no hover, focus, pressed, disabled, error or loading states. These remain the Figma source where the screenshots are silent.

## 2. Where things live

| What | Where |
|---|---|
| All tokens (the only place raw values may be written) | `src/styles/tokens.css` |
| Component styles (tokens only) | `src/components/**/*.css`, `src/features/**/*.css` |
| Style guide page | `src/design-system/` (route `/design-system`) |
| Token checker | `scripts/check-tokens.mjs` (`npm run check:tokens`, also runs before `npm run build`) |
| Visual regression harness (dev only) | `scripts/ds-snapshot.js` |
| Measurements behind this document | `docs/screenshot-audit.md` |
| Demo panel | `src/demo/`. **Not part of the design system** |

## 3. Tokens

### 3.1 Naming

`--<category>-<role>[-<variant>]`. Names say what a value is for. Existing token names are unchanged; new names are marked **new**.

- Colour: `--color-text-*`, `--color-surface-*`, `--color-border-*`, `--color-icon-*`, `--color-divider`, `--color-overlay-scrim*`, `--color-focus-ring`, `--color-neutral-*`, `--color-canvas`.
- Type: `--text-<style>-size` with `--text-<style>-leading` (always a pair), `--weight-*`, `--font-family`, `--font-family-numeric`.
- Space: `--space-xs … --space-3xl` (4, 8, 12, 16, 24, 32, 40) and `--space-optical-N` for off-grid values.
- Radius (by use): see 3.5.
- Border width: `--border-width-default` 1, `-strong` 2, `-selected` 1 (**changed from 3**).
- Effects: `--shadow-card`, `--opacity-*`, `--focus-ring-*`.
- Layout: `--screen-width` 440, `--screen-height` 956.

### 3.2 Colour

**Brand and action**

| Token | Value | Use | Status |
|---|---|---|---|
| `--color-surface-brand` | `#2c4035` | Primary button fill | **Real** (was `#006564`) |
| `--color-text-inverse` | `#ffffff` | Label on primary button | Real (est.) (reads `#f8fffd`) |
| `--color-text-brand` | `#336c6a` | IATA codes, links, active tab and nav, route times | **Real** for fills, Real (est.) for text (was `#006564`) |
| `--color-border-brand` | `#336c6a` | Selected option border, outlined-button border and label | Real (est.) (thin line; was `#006564`) |
| `--color-text-brand-deep` **new** | `#035256` | Fare tier names, comparison column heads, Economy tab on fare screens | Real (est.) ±5 |
| `--color-border-brand-deep` **new** | `#025b61` | Tab indicator on fare screens | Real (est.) |
| `--color-icon-brand` | `#336c6a` | Teal icons (active nav, swap, filter, plane) | Real (est.). Icon files are retained; this is the colour they render in |
| `--color-gradient-segment` **new** | `#337776` to `#056065`, left to right | Selected segment fill (Economy) | Real (est.) |
| `--color-gradient-fare-light` **new** | `#c7d9d9` to `#94bdbf` | Fare-card top strip, Light | Real (est.) |
| `--color-gradient-fare-essential` **new** | `#93babd` to `#347a83` | Fare-card top strip, Essential | Real (est.) |
| Fare-card strip, Flex | darker teal, **not sampled** | | Not measured |

**Text**

| Token | Value | Use | Status |
|---|---|---|---|
| `--color-text-primary` | `#262626` | Body, titles, flight times | **Real (est.)** ±8 (was `#172e33`). Thin strokes read lighter, so true value is the same or darker |
| `--color-text-secondary` | `#6b6b6b` | Labels, meta, "Per Adult From", "Not available" | **Real (est.)** ±8 (was `#647578`). Reads `#646464` to `#757575` |
| `--color-text-strong` | `#000000` | Row labels and group heads in sheets and the comparison table | Real. v1.0 use ("flight card, nav labels") was wrong: flight-card text is primary, nav labels are secondary |
| `--color-text-accent` | `#8a6040` | "Lowest Fare", "N Seats Left" | **Real (est.)** ±10 (was `#ecaa4d`) |
| `--color-text-chip` **new** | `#905730` | Text on the peach chip | Real (est.) ±12 |
| `--color-text-class-premium` **new** | `#3a677b` | "Premium Economy" label | Real (est.) ±6 |
| `--color-text-class-business` **new** | `#182c51` | "Business" label | Real (est.) ±6 |
| `--color-text-warning` | `#886a38` | "Booked" chip | Figma (kept), not visible |
| `--color-text-caution` | `#854d0e` | Arrival-window badge | Figma (kept), not visible |
| `--color-text-danger` | `#ff474c` | Late time, field errors | Figma (kept), not visible. Flagged: 3.36:1 on white |
| `--color-text-pass` | `#796c69` | "PASSED" stamp | Figma (kept), not visible |

**Surfaces**

| Token | Value | Use | Status |
|---|---|---|---|
| `--color-canvas` | `#f8f8f8` | Screen background (Book, Results, Fare) | **Real** (v1.0 `#444444` was the page behind the phone frame; that is renamed, see below) |
| `--color-canvas-home` **new** | `#f9f8f6` | Home screen background | Real |
| `--color-canvas-warm` **new** | `#f2f1ef` | Fill-in-information and Insurance background | Real |
| `--color-canvas-frame` **new** | `#444444` | Page behind the phone frame (desktop only) | Figma (kept). Not product UI. Was named `--color-canvas` |
| `--color-surface-default` | `#ffffff` | **Cards**, sheets, bars, secondary button | **Real** (was "screen") |
| `--color-surface-panel` **new** | `#f9f9f9` | Inner panel inside fare cards, comparison footer | Real (est.) |
| `--color-surface-brand-subtle` | `#e9f3f2` | Selected option, Flex column, tinted callouts | Real (was `#e6f2ef`; within ±3, so effectively the same) |
| `--color-surface-banner` **new** | `#e5eeeb` | "Flying soon?" banner (darker `#d8e6e6` toward lower left; may be a gradient) | Real (est.) |
| `--color-surface-chip-brand` **new** | `#e4eeef` | "Economy Light" chip | Real (est.) |
| `--color-surface-table-head-a` / `-b` **new** | `#f9fdfe` / `#f6fafb` | Comparison column heads (Light / Essential) | Real |
| `--color-surface-chip` **new** | `#feede6` | Peach chip (promo, "Recommended") | **Real** |
| `--color-surface-subtle` | `#f4f8f7` | Not seen in the real app | Figma (kept), not visible |
| `--color-surface-field` | `#fbfbfb` | Search form, date chips | Figma (kept). Value is within ±2 of `surface-panel`; **your merge decision** |
| `--color-surface-warning` / `-caution` | `#fbf5ea` / `#fff3d6` | "Booked" chip, arrival badge | Figma (kept), not visible. The real chip is the peach pair above |
| `--color-surface-fare` | `#a8dcab` (25%) | Fare panel | Figma (kept), not visible |

**Borders, lines, overlays**

| Token | Value | Use | Status |
|---|---|---|---|
| `--color-border-default` | `#e8e8e8` | Card and option borders, table lines | **Real** (was `#dce6e4`). Reads `#e7e7e7` to `#eaeaea`. Flagged: 1.24:1 on white |
| `--color-divider` | `#e8e8e8` | Rules, header and tab-row dividers | **Real** (was `#dce6e4`) |
| `--color-border-handle` **new** | `#e3e3e3` | Sheet handle | Real (est.) |
| `--color-border-radio` **new** | `#b9b9b9` | Unselected radio ring | Real (est.) ±20. Thin line; true value probably darker |
| `--color-overlay-scrim` | `rgba(0,0,0,.40)` | Express checkout sheet backdrop | **Real**. Resulting colours exact, alpha ±2% (was tinted `rgba(23,46,51,.44)`) |
| `--color-overlay-scrim-light` **new** | `rgba(0,0,0,.32)` | Upgrade sheet backdrop | Real (est.). One capture, may be mid-fade |
| `--color-overlay-veil` **new** | `rgba(255,255,255,.80)` | In-flow loading veil over the whole screen | Real (est.) |
| `--color-loader-mark` **new** | `#5f9691` | Loading circle (about 81 dp) behind a white seat glyph | Real (est.) |
| `--color-text-progress-end` **new** | `#e4e5e6` | Inactive end label on loading progress | Real (est.). Flagged: 1.26:1, decorative |
| `--color-border-inverse` | `#ffffff` | Avatar ring | Figma (kept), not visible |
| `--color-border-strong` / `-alt` | `rgba(0,0,0,.43)` / `.54` | Flight card, search controls | Figma (kept), **not visible**. Real flight cards have no border |
| `--color-border-danger` | `#ff474c` | Invalid field | PROPOSAL |
| `--color-border-pass` | `#796c69` | Stamp | Figma (kept), not visible |
| `--color-neutral-line` / `-track` | `#d9d9d9` / `#d3d3d3` | Dividers, progress tracks | Figma (kept). The real grey track is visible but **not sampled** |
| `--color-focus-ring` | `#336c6a` | Focus ring | PROPOSAL (was `#006564`; follows the new brand teal) |

**Icons.** Icon and vector files are retained exactly. `--color-icon-default` stays `#141b34` (Figma style "Dark"). The real app's content icons read about `#191919` to `#2a2a2a` and inactive nav icons about `#595959` to `#646464`. This is a note only; no icon is changed here.

### 3.3 Typography

**Family.** v1.0 says Inter. The real app's typeface **cannot be identified from the screenshots**, so Inter is kept (Figma kept) and is not confirmed. `--font-family-numeric` (Lexend, flight search filters) is kept; no filter screen was captured.

Sizes below are Real (est.) at ±1.5 sp, from cap-height ÷ 0.71 (assumed ratio). Where they match a v1.0 style, the v1.0 size and leading pair is kept.

| Style | Size / leading | Used for | Status |
|---|---|---|---|
| micro | 10 / 12 | Bottom-nav labels (secondary colour, not black) | Real (est.) |
| caption-sm | 11 / 13 | Dense meta | Figma (kept), not evidenced |
| caption | 12 / 15 | Field labels ("Departing"), "Good value", "N Seats Left" | Real (est.) |
| body-sm | 13 / 16 | Date tabs, flight number | Real (est.) |
| body | 14 / 17 | City names, fare row labels | Real (est.) |
| body-lg | 15 / 18 | Intro and placeholder copy | Figma (kept), not evidenced |
| body-xl | 16 / 19 | Field values, "Select" label, result price | Real (est.) |
| title-xs | 17 / 21 | | Figma (kept), not evidenced (cannot separate 17 from 18) |
| title-sm | 18 / 22 | Result times and airport codes, Home card title, insurance heading | Real (est.) |
| title-md / title | 19 / 23, 20 / 24 | Fare tier name (bold, deep teal), fare price (bold) | Real (est.) |
| **button** **new** | **18 / 22** | Button labels ("Search flight", "Straight to payment") | Real (est.). v1.0 used body-xl 16 |
| **bar-title** **new** | **20 / 24** | App-bar title and sheet title. **Regular weight, `text-primary`, centred** | Real (est.). Replaces v1.0 use of `page-title` for these |
| heading-sm / md | 21 / 25, 22 / 27 | Section titles ("Passenger", "Our latest offers"), regular weight | Real (est.) |
| heading | 23 / 28 | | Figma (kept), not evidenced |
| page-title | 25 / 30 | **Not used by the real app** for app-bar or sheet titles. Kept for any in-page title Figma defines | Figma (kept) |
| display-sm | 26 / 31 | Home IATA ("HKG", "Search"), bold, mid-teal. Splash headline: 26 on **33.4 lines** (see leading) | Real (est.) |
| **hero-code** **new** | **34 / 41** (leading estimated) | Book-screen IATA code, bold, mid-teal | Real (est.). 34 sits between `display` 32 and `code` 36; needs a native crop |
| display | 32 / 39 | | Figma (kept) |
| code / timer | 36 / 44, 44 / 53 | Invite code, countdown | Figma (kept), not visible |
| glyph | 34 | Mark inside state messages | PROPOSAL |

**Weights.** Regular 400 for most text. Bold for IATA codes, prices, tier names and the selected segment. The real app's 500 versus 600 cannot be told apart, so `--weight-medium` and `--weight-semibold` are kept (Figma) and unverified.

**Leading.** v1.0 ratios `--leading-body` 1.45, `--leading-tight` 1.4, `--leading-heading` 1.2 are kept (Figma) except where measured:

| Text | Measured line spacing | Status |
|---|---|---|
| Splash headline (26 sp, 2 lines) | **33.4** (about 1.28) | Real. Replaces 31 for multi-line |
| Insurance bullets and option copy (about 16 sp) | **24.5 to 25.6** (about 1.55) | Real (est.). Looser than 1.45 |
| Sheet body ("Upgrade for just…") | 26.2. Size not measured | Real (line spacing only) |
| Express checkout body | 20.1. Size not measured | Real (line spacing only) |

### 3.4 Old name to new name (v1.0 prototype names, still valid)

| Old | New |
|---|---|
| `--color-primary` | `text-brand` (colour), `surface-brand` (background), `border-brand` (border). **Values now differ per role** |
| `--color-ink` / `--color-muted` / `--color-black` | `text-primary` / `text-secondary` / `text-strong` |
| `--color-white` | `text-inverse` (colour), `surface-default` (background), `border-inverse` (border) |
| `--color-surface` | `surface-subtle` (Figma kept); the real app's grey is `canvas` |
| `--color-tint` | `surface-brand-subtle` (background), `text-brand` (colour) |
| `--color-border` | `border-default` (border), `divider` (background lines) |
| `--color-sand` / `--color-sand-ink` | `surface-warning` / `text-warning` |
| `--color-alert` | `text-danger` (colour), `border-danger` (border) |
| `--color-scrim` | `overlay-scrim` |
| `--color-outline` / `--color-card-line` | `border-strong-alt` / `border-strong` |
| `--font-semibold` etc. | `--weight-semibold` etc. |
| `--fs-N` | `--text-<style>-size` |
| `--lh-body` / `--lh-tight` | `--leading-body` / `--leading-tight` |
| `--space-N` | `--space-xs…3xl` or `--space-optical-N` |
| `--radius-8` / `-14` / `-10` | `--radius-control` / `-panel` / `-button-lg` |

**Merges.** Only one merge has been made: `#D9D9D9` and the Figma variable `#CFCFCF` are one value (`--color-neutral-line`). v2.0 makes none. `border-default` and `divider` now share `#e8e8e8` but remain two tokens.

### 3.5 Spacing and radius

**Spacing** scale is unchanged: 4, 8, 12, 16, 24, 32, 40, plus `--space-optical-N` (2, 3, 5, 6, 7, 9, 10, 13, 14, 18, 20, 22, 28, 30).

| Token / rule | Value | Where | Status |
|---|---|---|---|
| Gutter, standard | 24 (`--space-xl`) | Book, Results, Fare, Fill-in, Insurance, Upgrade sheet | Real |
| Gutter, tight **new** `--gutter-tight` | 16 (`--space-lg`) | **Home** and **Express checkout** sheet | Real. v1.0 said 24 everywhere |
| Card inner padding: Book card | 24 | | Real |
| Card inner padding: Fill-in and Insurance cards | 16 | | Real |
| Fare-card panel inset | 11 to 12 (use 12; 11 is not on the scale) | | Real (est.) |
| Gap between result cards | 16 | | Real |
| Gap between fare cards | about 24 | | Real (est.) |
| Result card height | 129 | | Real |
| Result card split | left 242, right 120, 1 dp divider | | Real |
| Fare-card top strip height | 6 | | Real |
| Tab row height | 48 | | Real |
| Tab indicator | about 3 thick, same width as the label | | Real (est.) |
| Top of screen to first divider | 91 (includes the system status bar) | | Real. Status bar and app bar cannot be split |
| Bottom nav | 5 equal items, about 82 wide; icon-to-label gap about 6.7; hairline above | | Real. Bar height not visible |
| Fare-row label column | labels start at one x regardless of icon width; icon box about 24, gap 11 to 13 | | Real |

**Button heights** `--size-button-*`

| Size | Value | Where | Status |
|---|---|---|---|
| Standard | **52** | Book "Search flight", Upgrade sheet buttons | Real |
| Large | **56** | "Continue" on Fill-in, both Express checkout buttons | Real. Figma had 54 (not built) |
| Small | **38** | "Select" in a fare card | Real. Figma had 39 (not built) |
| 48 | | | Figma (kept), not visible |

**Radius** (Real (est.) ±1.5 dp)

| Token | Value | Used for | Status |
|---|---|---|---|
| `--radius-hairline` | 2 | | Figma (kept), not seen |
| `--radius-bar` | 3 | "Economy Light" chip | Real (est.) |
| `--radius-chip` **new** | 4 | Peach chip | Real (est.). No existing token fits (between `bar` 3 and `badge` 5) |
| `--radius-badge` | 5 | | Figma (kept), not seen |
| `--radius-thumb` | 6 | Selected insurance option, Home banner | Real (est.) |
| `--radius-control` | 8 | **All buttons**, result cards, Fill-in cards, inner panels | Real |
| `--radius-button-lg` | 10 | | Figma (kept). Fare card (10.6) fits either this or `card`; needs a native crop |
| `--radius-card` | 12 | Book search card | Real |
| `--radius-panel` | 14 | | Figma (kept), not seen |
| `--radius-card-lg` | 16 | **Bottom-sheet top corners** | Real (est.). Replaces `sheet` |
| `--radius-sheet` | 20 | | Figma (kept), **not used by the real app**. Sheets use 16 |
| `--radius-pill` | 100 | Swap button, radios, check circles, loading mark | Real |

**Borders**

| Token | Value | Status |
|---|---|---|
| `--border-width-default` | 1 | Real |
| `--border-width-strong` | 2 | Figma (kept), not seen |
| `--border-width-selected` | **1** (was 3) | Real (est.). Selected option is a 1 dp teal border on `surface-brand-subtle` |

**Shadow.** `--shadow-card` is **Real (est.)**: soft, visible about 13 dp on every side, peak darkening about 3% of the canvas, borderless cards. Offset and blur cannot be recovered from a screenshot, so the exact CSS is **not set here**. Until it is tuned against the real card, v1.0's "XXS Shadow" stays in `tokens.css` and is flagged.

**Effects (unchanged).** `--opacity-hover` 0.9, `-pressed` 0.8, `-disabled` 0.6, `--focus-ring-width` 2, `--focus-ring-offset` 2: PROPOSAL, because the real app's states are not visible.

**Layout.** `--screen-width` 440, `--screen-height` 956: Figma (kept).

## 4. Components

**R** = in the real app, **F** = Figma only, **P** = proposal.

| Component | Real-app definition | Status |
|---|---|---|
| Button, primary | 52 or 56 tall, radius 8, `#2c4035`, white label 18 sp | R. v1.0 was `#006564` 52, 16 px |
| Button, secondary | 52 or 56 tall, white, 1 dp teal border, teal label | R (structure) |
| Button, small | 38 tall, same green, label 16 sp | R |
| Tabs | Text, 3 dp indicator under the active one. Active is mid-teal (Book, Results) or deep teal (fare screens). Inactive is dark or grey. 48 tall | R. v1.0: "defined in Figma, not built" |
| Segmented control | Economy / Premium Economy / Business with price delta. Selected has the teal gradient and a white label | R, new |
| Flight (ticket) card | White, radius 8, no border, soft shadow. Left 242, right 120, 1 dp divider | R |
| Fare card | 6 dp gradient strip, tier name (deep teal), price, grey inner panel with 4 rows, "Fare comparison" link, small Select | R |
| Chip | **Peach** `#feede6` with `#905730` text, radius 4 (promo, Recommended). **Teal-tint** `#e4eeef`, radius 3 (fare label). The v1.0 variants `neutral`, `primary`, `sand`, `tint` have no real-app match except tint | R, replaces `sand` for the peach case |
| Field (Book form) | **No box.** Label (caption, secondary), value (16), 1 dp divider below, chevron at right | R. v1.0 field was bordered |
| Option row (radio) | 1 dp border, radius 6. Selected: teal border and `#e9f3f2` fill, filled radio | R |
| Bottom sheet | White, radius 16, centred 4 dp handle, left close X, centred title (20, regular) | R. v1.0: 20 radius |
| Scrim | Neutral black. 40% (Express), 32% (Upgrade) | R |
| Sticky footer | White bar, hairline above, "Total HKD…" left, 56 dp Continue right | R |
| Comparison table | 3 columns, tinted heads, tint on Flex column, fixed price footer with Select | R |
| Bottom nav | 5 equal items: Home, Book, My trips, Profile, Travel tools. Active teal with heavier icon. Inactive grey. Hairline above | R. v1.0's "Travel Groups" tab is **not in the real app** |
| Page header | Back chevron left, centred regular title (20), 1 dp divider below | R. v1.0: `page-title`, semibold, brand |
| Photo header | Tokyo photo, dark overlay, white title and dates, rounded bottom-left curve | R. Overlay colour not measured |
| Loading splash | Photo or window illustration, headline, HKG to HND progress with plane glyph | R |
| Loading, in flow | 80% white veil over the screen plus a teal circle with a white seat glyph. No per-button spinner is visible | R |
| Unavailable | "Not available" date tab is plain `text-secondary`, no fill | R (one example) |
| Group card, Trip context, Member row, Section heading, Bonus teaser | Not in the real app screenshots | F (kept, unverified) |
| Sheet + scrim (decline-invite sheet) | Structure follows the bottom sheet above | F + R |
| State message | confirmation, building | F; real loading is the veil and mark above |
| Skeleton, Toast, inline field error | Not visible | P |

**States.** Real-app states visible: selected (tab, option, segment), loading (veil), unavailable (grey text). **Not visible, so Figma/proposal values are kept**: hover, pressed, focus, disabled, error, empty. S12's grey Continue is a screen-level veil, not a disabled style.

**Proposed state styles use tokens only**: hover `--opacity-hover` (0.9), pressed `--opacity-pressed` (0.8), disabled `--opacity-disabled` (0.6), focus `--focus-ring-*`. `is-hover`, `is-pressed`, `is-focus` classes mirror the pseudo-classes for the style guide only; product code must not set them.

**Defined in Figma, not built yet:** text action, callout variants, avatar sizes, 48 button size. Built from this system when their screens arrive. Tabs, flight, fare and suggestion cards now have real-app definitions above.

Component rules (unchanged unless noted):

- Reuse a component before writing markup. If none fits, propose one (name, variants, states, real-app screenshot or **PROPOSAL**) and wait for approval.
- One primary button per screen. Loading sets `disabled` and `aria-busy` and keeps the label.
- Every field has a visible label; errors sit under the field with `role="alert"` and are linked with `aria-describedby`.
- A card is one link. Do not nest another link or button inside it.
- Chips show status only. The label carries meaning, never colour alone.

## 5. Usage rules

**Spacing.** Use the scale (4, 8, 12, 16, 24, 32, 40). Gutter is `--space-xl` (24) on Book, Results, Fare, Fill-in, Insurance and the Upgrade sheet, and `--gutter-tight` (16) on Home and the Express checkout sheet. Do not use one gutter for every screen.

**Text hierarchy.** App-bar and sheet title (`bar-title`, 20, regular), section heading (`heading-sm` / `heading-md`, regular), card and tier title (`title-sm` to `title`), body (`body` / `body-xl`), meta (`caption`), micro labels (`micro`). Do not skip to an unrelated size to "fit"; ask for a new style.

**Colour.** Text uses `--color-text-*`, backgrounds `--color-surface-*`, outlines `--color-border-*`. **Screens use `--color-canvas`; cards and sheets use `--color-surface-default` (white).** The dark green `surface-brand` is for the primary action only. Mid-teal marks codes, links, active and selected states. Deep teal marks fare tiers and table heads.

**Layout.** The screen is 440 px wide. At 768 px and below it fills the viewport; above, it is centred on `--color-canvas-frame`. Every screen starts with a status bar and page header (centred title, back chevron left). The page title is the `h1` and takes focus after navigation. Bottom nav sits at the bottom.

**Accessibility.** Text needs 4.5:1; borders and focus rings need 3:1. Every interactive element has a visible focus ring (2px brand, 2px offset), an accessible name, and works by keyboard. Sheets trap focus and close on Escape. Motion respects `prefers-reduced-motion`.

## 6. Accessibility findings

Measured from the real app's colours. Thin text reads lighter than its true colour, so the true ratios are the same or higher.

| Pair | Ratio | Result |
|---|---|---|
| text-primary `#262626` on white | 15.1 | pass |
| text-primary on canvas-warm `#f2f1ef` | 13.4 | pass |
| text-secondary `#6b6b6b` on white | 5.3 | pass |
| text-secondary `#6b6b6b` on surface-brand-subtle `#e9f3f2` | 4.71 | pass |
| text-secondary `#6f6f6f` on canvas-warm `#f2f1ef` | 4.45 | **fails small text** |
| text-secondary `#757575` (lightest read) on canvas-warm | 4.08 | **fails small text** |
| text-brand `#336c6a` on white / on `#e9f3f2` / on `#f2f1ef` | 6.0 / 5.3 / 5.3 | pass |
| text-brand-deep `#035256` on white | 9.0 | pass |
| text-inverse on surface-brand `#2c4035` | 11.1 | pass |
| text-inverse on `#336c6a` | 6.0 | pass |
| text-accent `#8a6040` on white | 5.5 | pass |
| text-chip `#905730` on surface-chip `#fcede6` | 5.1 | pass |
| border-default / divider `#e7e7e7` on white | 1.24 | **below 3:1** (the real app does the same) |
| `#e7e7e7` on canvas `#f8f8f8` / on `#f2f1ef` | 1.16 / 1.10 | **below 3:1** |
| border-brand selected (about `#3f6a64`) on `#e9f3f2` | 5.4 | pass |
| border-radio `#b9b9b9` on white | 1.96 | **below 3:1**, thin read so true value may be darker |
| text-progress-end `#e4e5e6` on white | 1.26 | fails (decorative label) |
| text-danger `#ff474c` on white | 3.36 | **fails small text** (Figma kept, not visible) |
| text-secondary v1.0 `#647578` on white | 4.82 | superseded |
| text-accent v1.0 `#ecaa4d` on white | 2.01 | superseded; the real app does not use it |

The failing values that are observed in the real app are kept as observed (rule 0). Remedies are in section 8 as proposals.

## 7. Enforcement checklist

Before any screen is reviewed:

1. Colours, sizes, spacing, radii, weights and borders come from tokens. No raw values in component CSS.
2. Existing component reused. New component proposed and approved first.
3. Hover, pressed, focus and disabled behave; loading and error states exist where data loads or forms submit.
4. Contrast checked (4.5:1 text, 3:1 borders and focus). New failures are flagged, not hidden.
5. Checked at 375px and at 440px or wider.
6. **The screen is compared against the matching real-app screenshot** and `docs/screenshot-audit.md` when one exists.
7. `npm run check:tokens` passes (it also blocks `npm run build`).
8. Component added or updated in `/design-system`, labelled R, F or P.

`check:tokens` fails on: raw hex/rgb colours, raw `font-size`, `line-height`, spacing, radius or border widths, numeric font weights, `:root` outside `tokens.css`, and unknown `var(--…)`. A deliberate exception needs a `ds-allow:` comment with the reason.

Changing a token value or adding a style is a material design change: ask first.

## 8. Decisions awaiting approval

| # | Proposal | Why |
|---|---|---|
| A | Darker text-only danger colour (for example `#d6303a`, about 4.8:1) | `#ff474c` is 3.36:1. No error state exists in the real app screenshots to settle it |
| B | Stronger border (3:1) for field error and focus only | The real app's own dividers are 1.24:1, so this would deliberately differ from it |
| C | Confirm `text-secondary` grey | Readings `#6f6f6f` and `#757575` fail 4.5:1 on `#f2f1ef`; `#6b6b6b` passes |
| D | Merge near-duplicates | Now evidence-based: `text-strong` and `text-primary` are **both used** by the real app (keep two). `surface-field` is within ±2 of `surface-panel`. Observed greys `#f8f8f8` / `#f9f9f9` / `#f9f8f6` / `#f2f1ef` / `#f6f6f6` are not merged here. caution vs warning and strong vs strong-alt are not visible |
| E | Fix the `#056564` typo in one icon (app copy only) | Unchanged; icons retained |
| F | Convert icons to `currentColor` | Unchanged |
| G | Hover/pressed/disabled values | Not visible in the real app |
| H | Set `--shadow-card` from the real card | Needs a native-resolution crop to recover blur and offset |
| I | Settle `hero-code` 34 vs 32 or 36, fare-card radius 10 vs 12 | Needs native crops |
| J | Replace the "Travel Groups" tab | The real app's tabs are Home, Book, My trips, Profile, Travel tools. Product decision |

## 9. Verification

- **v1.0 (still true for the code today):** the token migration compared 16 states before and after at 1280px and 578px; `npm run check:tokens` passed on 26 stylesheets and `npm run build` succeeded.
- **v2.0:** values were measured from 14 real-app screenshots (see `docs/screenshot-audit.md`). `tokens.css` and component CSS have **not** been updated, re-checked or rebuilt against v2.0.

## 10. Token changes needed in `src/styles/tokens.css`

Value changes (same name):

| Token | v1.0 | v2.0 |
|---|---|---|
| `--color-surface-brand` | `#006564` | `#2c4035` |
| `--color-text-brand`, `--color-border-brand`, `--color-icon-brand`, `--color-focus-ring` | `#006564` | `#336c6a` |
| `--color-text-primary` | `#172e33` | `#262626` |
| `--color-text-secondary` | `#647578` | `#6b6b6b` |
| `--color-text-accent` | `#ecaa4d` | `#8a6040` |
| `--color-surface-brand-subtle` | `#e6f2ef` | `#e9f3f2` |
| `--color-border-default`, `--color-divider` | `#dce6e4` | `#e8e8e8` |
| `--color-overlay-scrim` | `rgba(23,46,51,.44)` | `rgba(0,0,0,.40)` |
| `--color-canvas` | `#444444` | `#f8f8f8` (old value moves to `--color-canvas-frame`) |
| `--radius-sheet` use | 20 | sheets use `--radius-card-lg` (16) |
| `--border-width-selected` | 3px | 1px |

Component and role changes (no token rename): primary buttons and secondary-button labels, surface roles (cards white, screens canvas), bottom-sheet radius, app-bar and sheet title style, button label 18, nav labels `text-secondary`, field has no box, Home and Express use the tight gutter, nav tabs.

New tokens: `text-brand-deep`, `border-brand-deep`, `text-chip`, `text-class-premium`, `text-class-business`, `canvas-home`, `canvas-warm`, `canvas-frame`, `surface-panel`, `surface-banner`, `surface-chip-brand`, `surface-table-head-a`, `surface-table-head-b`, `surface-chip`, `border-handle`, `border-radio`, `overlay-scrim-light`, `overlay-veil`, `loader-mark`, `text-progress-end`, `gradient-segment`, `gradient-fare-light`, `gradient-fare-essential`, `gutter-tight`, `size-button-lg`, `size-button-sm`, `radius-chip`, `text-button-*` (18/22), `text-bar-title-*` (20/24), `text-hero-code-*` (34/41, leading estimated).

Icons and vectors are retained exactly as they are.
