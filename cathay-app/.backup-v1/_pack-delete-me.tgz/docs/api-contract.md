# API contract (Flow A: travel groups and invitations)

The front end talks to the backend only through `src/api/groups.js` and `src/api/users.js`.
Those call `request(method, path, body)` in `src/api/http.js`. Today `request` is answered by an
in-browser mock (`src/api/mock/`, saved in `localStorage`). To use a real server, change only
`request()` to `fetch()` the endpoints below, with the same JSON, and throw an `ApiError`
(`src/api/errors.js`) for any non-2xx response.

- Base path: `/api` (prefix it in `request()`).
- JSON in, JSON out. Dates are display strings for now (see "Notes").
- The caller is identified by the session (cookie or bearer token). It is the "signed-in person".
- Mutations resolve with the full updated `Group`.

## Error format

Every non-2xx response has this body:

```json
{ "code": "invite_not_found", "message": "This invitation link is not valid.", "fields": null }
```

`fields` is only set for `422` and maps a field name to a message:

```json
{ "code": "validation_failed", "message": "Some fields need attention.", "fields": { "name": "Enter a group name." } }
```

| HTTP | `code` | When |
|---|---|---|
| 401 | `unauthenticated` | No signed-in person |
| 403 | `invalid_invite_code` | `inviteCode` does not match the group and the user was not invited |
| 403 | `not_a_member` | Action needs group membership |
| 404 | `group_not_found` | Unknown group id |
| 404 | `invite_not_found` | Unknown invite code |
| 409 | `already_member` | Declining while already a member |
| 422 | `validation_failed` | Invalid request body |
| 503 | `service_unavailable` | Temporary outage (the UI shows "Retry") |

The UI treats `invite_not_found` from `GET /invitations/:code`
as "This invitation isn't available".

## Shared types

### User

```json
{ "id": "clara", "name": "Clara", "initial": "C", "airport": { "code": "SHA", "city": "Shanghai" } }
```

### Group (as seen by the signed-in person)

```json
{
  "id": "tokyo-together",
  "name": "Tokyo together",
  "destination": "Tokyo, Japan",
  "datesLabel": "Nov 7–10, 2026",
  "code": "VFX37K",
  "inviteUrl": "https://flights.cathaypacific.com/share/VFX37K",
  "creatorId": "gaudi",
  "inviteCopied": false,
  "members": [
    { "userId": "gaudi", "name": "Gaudi", "initial": "G", "airport": { "code": "HKG", "city": "Hong Kong" }, "status": "booked" },
    { "userId": "kabe", "name": "Kabe", "initial": "K", "airport": { "code": "SIN", "city": "Singapore" }, "status": "picked" }
  ],
  "viewerId": null,
  "viewerRole": "invitee",
  "invitation": "pending"
}
```

| Field | Notes |
|---|---|
| `members[].status` | `browsing`, `picked` or `booked` |
| `viewerId` | The signed-in user's id if they are a member, otherwise `null` |
| `viewerRole` | `creator`, `member`, `invitee` (invited or opened the link, not a member) or `null` |
| `invitation` | For non-members: `pending`, `declined` or `null`. Always `null` for members |
| `code` | Short invite code used in `/invite/:code` |
| `inviteUrl` | The link shown and copied in the app |

The UI never assumes who the viewer is: it reads `viewerId`, `viewerRole` and `creatorId`.

## Endpoints

### `GET /me`

Response `200`: a **User**.

### `GET /groups`

Groups the person belongs to or has been invited to (members first, newest first).

Response `200`:

```json
{ "groups": [ { "...": "Group" } ] }
```

### `POST /groups`

Creates a group; the caller becomes its creator and first member (`browsing`).

Request:

```json
{ "name": "Weekend in Tokyo", "destination": "Tokyo, Japan", "dates": "nov-7-10" }
```

Validation: `name` 1–30 characters; `destination` required (the demo accepts Tokyo only);
`dates` one of the available window ids (`nov-7-10`). Response `201`: a **Group**.
Errors: `422 validation_failed` with `fields`.

### `GET /groups/:id`

Response `200`: a **Group**. Errors: `404 group_not_found`.
(A real server may return `403` unless the caller is a member or invitee; the UI treats
`viewerId: null` as "go to the invitation".)

### `GET /invitations/:code`

Preview of the group behind an invite link. Response `200`: a **Group**.
Errors: `404 invite_not_found`.
Already-members always get `200`.

### `POST /groups/:id/join`

Request: `{ "inviteCode": "VFX37K" }`. Adds the caller as `browsing`, clears their invitation.
Idempotent for existing members. Response `200`: a **Group**.
Errors: `403 invalid_invite_code`.

### `POST /groups/:id/decline`

Request: `{ "inviteCode": "VFX37K" }`. Records `invitation: "declined"` for the caller. The
caller can still join afterwards. Response `200`: a **Group**.
Errors: `403 invalid_invite_code`, `409 already_member`.

### `POST /groups/:id/invite-copied`

No body. Marks that a member copied the invite link (`inviteCopied: true`). Response `200`: a **Group**.
Errors: `403 not_a_member`.

## Notes for the backend

- `datesLabel` is a display string today. Send ISO 8601 dates later and format them in the UI.
- There is no decision deadline and no member limit.
- Cover photos are chosen in the UI by destination; add an `imageUrl` field if you want the server to own them.
- Later flows (flights, payment, preferences, itinerary) will extend this contract.
- `src/demo` calls the mock database directly (switch person, add members, force errors). None of it
  maps to a real endpoint.
